﻿#if UNITY_EDITOR || RUNTIME_CSG
using System;

namespace Sabresaurus.SabreCSG
{
	public class PostProcessCSGBuildAttribute : Attribute
	{
		public PostProcessCSGBuildAttribute()
		{
			
		}
	}
}
#endif