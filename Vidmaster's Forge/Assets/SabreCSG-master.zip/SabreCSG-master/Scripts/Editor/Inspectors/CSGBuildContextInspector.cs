using UnityEngine;
using System.Collections;
using UnityEditor;

namespace Sabresaurus.SabreCSG
{
	[CustomEditor(typeof(CSGBuildContext))]
	public class CSGBuildContextInspector : Editor
	{
		public override void OnInspectorGUI()
		{
		}
	}
}
