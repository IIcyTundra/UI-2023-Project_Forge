﻿using UnityEngine;
using System.Collections;

namespace Sabresaurus.SabreCSG
{
	public class ExpandPropertiesAttribute : PropertyAttribute 
	{
		public ExpandPropertiesAttribute ()
		{
			
		}
	}
}